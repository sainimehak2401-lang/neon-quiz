# SpendWise — Smart Expense Tracker

SpendWise is a local-first personal finance tracker built with Python 3.11+, Streamlit, SQLite, Pandas, NumPy and Plotly. It records income and expenses, manages categories and monthly budgets, analyzes actual stored records, generates rule-based insights, and exports CSV, Excel and PDF reports.

## Problem statement and objectives
Personal financial records often live in scattered notes or spreadsheets. SpendWise centralizes records in a persistent SQLite database and presents clear summaries, category breakdowns, budget alerts and month-to-month comparisons without a paid service or external API.

## Features
- Dashboard with reporting-period filters, KPI cards, cash-flow charts, category distribution, daily spending and recent transactions.
- Add, edit, search, filter and delete income/expense transactions.
- Default and custom categories; duplicate names are rejected and categories can be deactivated without losing history.
- Overall and category-specific monthly budgets with utilization, remaining amount and warnings.
- Financial analytics and local rule-based insights.
- CSV and formatted Excel exports; PDF financial report generation.
- Currency display preference, date preference and configurable budget warning thresholds.
- SQLite backup download and validated restore with pre-restore backup.
- Automated pytest suite using temporary databases.
- First-run portfolio demo data (clearly tagged `DEMO`) so the dashboard is populated immediately; remove it from Dashboard → Demo data controls. Set `SPENDWISE_LOAD_DEMO_DATA=0` to disable first-run seeding.

## Technology stack
Python, Streamlit, SQLite (`sqlite3`), Pandas, NumPy, Plotly, openpyxl, ReportLab and pytest.

## Architecture
- `database/`: SQLite connection, schema initialization and repository (parameterized SQL).
- `services/`: reusable analytics, report generation and backup/restore logic.
- `utils/`: formatting, validation, date helpers and logging.
- `app.py`: Streamlit UI/navigation and page composition.
- `tests/`: isolated automated tests.

## Project structure
```text
SpendWise/
├── app.py
├── config.py
├── requirements.txt
├── README.md
├── .gitignore
├── database/
│   ├── connection.py
│   ├── schema.py
│   └── repository.py
├── services/
│   ├── analytics_service.py
│   ├── report_service.py
│   └── backup_service.py
├── utils/
│   ├── formatters.py
│   ├── validators.py
│   ├── date_utils.py
│   └── logger.py
├── assets/styles.css
├── tests/
│   ├── conftest.py
│   ├── test_database.py
│   ├── test_transactions.py
│   ├── test_budgets.py
│   └── test_analytics.py
└── data/
```

## Database design
- `transactions`: transaction type, amount in integer paise, category foreign key, date, payment method and optional descriptive fields.
- `categories`: unique category name per transaction type, active status and description.
- `budgets`: monthly overall or category budget; one budget per category/month/year (NULL category represents overall budget).
- `settings`: persistent key/value preferences.
- Foreign keys are enabled; useful date, type and category indexes are created. Amounts are stored as integer paise to avoid floating-point rounding in the database.

## Installation (Windows)
Open PowerShell or Command Prompt in the project folder.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Command Prompt activation:
```bat
.venv\Scripts\activate.bat
```
Streamlit prints a local URL, usually `http://localhost:8501`.

## Run tests
```powershell
python -m pytest -q
```
Tests use temporary SQLite files and do not touch your personal database.

## Database location
The default database is `data/spendwise.db`, created automatically on first startup. For portfolio demonstrations, an empty database is seeded once with clearly tagged illustrative records; remove them from the dashboard or set `SPENDWISE_LOAD_DEMO_DATA=0` before first launch to disable this behavior. To use another location, set `SPENDWISE_DB_PATH` before launching. The `data/` directory is ignored by Git because it contains private financial records.

## Reports and exports
Open **Reports and Export**, select a date range and report type, then download CSV, XLSX or PDF. Transaction screens also provide filtered CSV and Excel exports. Exports contain stored transaction records for the selected period.

## Backup and restore
Open **Settings → Database backup** to create and download a SQLite backup. To restore, upload a valid SpendWise database file, acknowledge the replacement warning, and run validation/restore. The current database is backed up before replacement. Keep backups in a secure location.

## Troubleshooting
- **`streamlit` not found:** activate `.venv`, then run `python -m pip install -r requirements.txt`.
- **Port already in use:** run `streamlit run app.py --server.port 8502`.
- **PowerShell activation blocked:** use Command Prompt activation or allow scripts according to your organization's policy.
- **Database permission error:** ensure the project/data folder is writable; alternatively set `SPENDWISE_DB_PATH` to a writable local path.
- **Missing charts/export dependencies:** rerun `python -m pip install -r requirements.txt`.
- **Restore rejected:** confirm the upload is a valid SQLite backup created from a SpendWise database.

## Screenshots
Add screenshots of Dashboard, Transactions, Budget Management, Analytics and Reports here after launching locally.

## Privacy and security
SpendWise is designed for local personal use and does not send financial records to external services. It does not implement authentication or database encryption. Protect your operating-system account, avoid sharing the database file, and maintain secure backups.

## Known limitations
- Single-user local application; no account login or synchronization.
- Currency preference changes the display symbol only; no currency conversion is performed.
- Insights are transparent, rule-based heuristics and are not financial advice.
- Reports currently focus on transaction summaries/details; PDF charts are not embedded.
- The interface is a single Streamlit navigation app rather than separate Streamlit multipage files.

## Future improvements
Optional authentication, encrypted backups, recurring transactions, receipt attachments, scheduled transactions, import mapping with duplicate detection, richer report templates and localization.

## License
MIT License. You may adapt this project for educational and portfolio use; add a full license file before redistribution.
