import logging
from pathlib import Path
from config import DATA_DIR

def get_logger():
    logger = logging.getLogger("spendwise")
    if not logger.handlers:
        handler = logging.FileHandler(DATA_DIR / "spendwise.log", encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
