from config import CURRENCY_SYMBOLS, DEFAULT_CURRENCY

def currency(value, code="INR"):
    symbol = CURRENCY_SYMBOLS.get(code, code + " ")
    return f"{symbol}{float(value or 0):,.2f}"

def paise_currency(value, code="INR"):
    return currency((int(value or 0))/100, code)
