from datetime import date, timedelta
import calendar

def month_bounds(year, month):
    return date(year, month, 1), date(year, month, calendar.monthrange(year, month)[1])

def previous_month(year, month):
    return (year-1,12) if month == 1 else (year,month-1)
