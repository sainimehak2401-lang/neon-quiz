from datetime import date
from decimal import Decimal, InvalidOperation

def validate_amount(value):
    try: amount = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError): return False, "Enter a valid amount."
    if not amount.is_finite() or amount <= 0: return False, "Amount must be greater than zero."
    return True, ""

def validate_date(value):
    try:
        parsed = date.fromisoformat(str(value))
        return True, parsed
    except (ValueError, TypeError):
        return False, None
