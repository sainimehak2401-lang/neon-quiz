from pathlib import Path
import sqlite3
import tempfile
from datetime import datetime
from database.connection import connect
from config import DB_PATH, BACKUP_DIR

def create_backup(db_path=None):
    source_path = Path(db_path or DB_PATH)
    if not source_path.exists():
        raise ValueError("Database does not exist yet.")
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    target = BACKUP_DIR / f"spendwise_backup_{datetime.now():%Y%m%d_%H%M%S}.db"
    src = connect(source_path)
    try:
        dest = sqlite3.connect(str(target))
        try: src.backup(dest)
        finally: dest.close()
    finally: src.close()
    return target

def validate_backup(uploaded_bytes):
    if not uploaded_bytes or len(uploaded_bytes) < 100:
        raise ValueError("The uploaded file is empty or too small to be a SQLite database.")
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        f.write(uploaded_bytes); f.flush()
        try:
            c = sqlite3.connect(f.name)
            integrity = c.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            c.close()
        except sqlite3.DatabaseError as e:
            raise ValueError("The uploaded file is not a valid SQLite database.") from e
    required = {"transactions","categories","budgets","settings"}
    if integrity != "ok" or not required.issubset(tables):
        raise ValueError("Backup validation failed: required SpendWise tables are missing or corrupted.")
    return True

def restore_backup(uploaded_bytes, db_path=None):
    import os
    target = Path(db_path or DB_PATH)
    validate_backup(uploaded_bytes)
    target.parent.mkdir(parents=True, exist_ok=True)
    # Keep a pre-restore copy before replacing the active file.
    if target.exists():
        create_backup(target)
    with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".restore", delete=False) as f:
        temp_path = Path(f.name)
        f.write(uploaded_bytes); f.flush()
    try:
        c = sqlite3.connect(str(temp_path))
        c.execute("PRAGMA integrity_check")
        c.close()
        os.replace(temp_path, target)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise
