"""Explicitly opt-in demo data for screenshots and classroom demonstrations."""
from datetime import date, timedelta
from database.repository import Repository, now_text
from database.connection import session


def load_demo_data(repo: Repository):
    """Add illustrative sample transactions, budgets and goals to an empty database."""
    if repo.one("SELECT id FROM transactions LIMIT 1"):
        raise ValueError("Sample data can only be loaded into an empty transaction database.")
    cats = {(c["transaction_type"], c["name"]): c["id"] for c in repo.categories()}
    today = date.today()
    # Deterministic illustrative monthly records; all are tagged DEMO for easy identification.
    monthly = [
        (5, 620000, 360000), (4, 645000, 375000), (3, 655000, 392000),
        (2, 668000, 381000), (1, 675000, 399000), (0, 684000, 321000),
    ]
    entries=[]
    for months_ago, income, expense in monthly:
        month_index = today.year * 12 + today.month - 1 - months_ago
        year, month0 = divmod(month_index, 12)
        month = month0 + 1
        day = min(3, __import__('calendar').monthrange(year, month)[1])
        entries.append(("Income", income/100, "Salary", date(year,month,day), "Bank Transfer", "Monthly salary", "Employer", "DEMO"))
        entries.append(("Expense", expense/100, "Rent", date(year,month,min(5,__import__('calendar').monthrange(year,month)[1])), "Bank Transfer", "Rent payment", "Home", "DEMO"))
        day_names = [("Food", 420, "UPI", "Whole Foods Market"), ("Transportation", 185, "UPI", "Metro / fuel"),
                     ("Groceries", 560, "Debit Card", "Grocery store"), ("Entertainment", 120, "Credit Card", "Streaming and movies"),
                     ("Shopping", 245, "UPI", "Personal shopping"), ("Subscriptions", 59.9, "Credit Card", "Subscriptions")]
        for i,(category, amount, payment, merchant) in enumerate(day_names):
            d=min(8+i*3,__import__('calendar').monthrange(year,month)[1])
            entries.append(("Expense",amount,category,date(year,month,d),payment,merchant,merchant,"DEMO"))
    for typ, amount, category, day, payment, desc, merchant, tag in entries:
        repo.add_transaction({"transaction_type":typ,"amount":amount,"category_id":cats[(typ,category)],
            "transaction_date":day.isoformat(),"payment_method":payment,"description":desc,"merchant":merchant,"notes":"Illustrative SpendWise demo record","tags":tag})
    now=now_text()
    with session(repo.db_path) as c:
        # Current-month budgets, only if not already present.
        c.execute("INSERT OR IGNORE INTO budgets(name,category_id,amount_paise,month,year,created_at,is_demo) VALUES(?,?,?,?,?,?,1)",
                  ("Monthly overall budget",None,500000,today.month,today.year,now))
        for name,amount in [("Food",500000),("Transportation",250000),("Entertainment",150000),("Shopping",300000)]:
            cid=cats[("Expense",name)]
            c.execute("INSERT OR IGNORE INTO budgets(name,category_id,amount_paise,month,year,created_at,is_demo) VALUES(?,?,?,?,?,?,1)",
                      (f"{name} budget",cid,amount,today.month,today.year,now))
        for name,target,saved,days in [("New Apartment",2500000,640000,180),("Japan Trip",1500000,520000,240),
                                      ("Investment Fund",3000000,960000,365),("New Car",8000000,1200000,540)]:
            c.execute("INSERT INTO savings_goals(name,target_paise,saved_paise,target_date,created_at,is_demo) VALUES(?,?,?,?,?,1)",
                      (name,target,saved,(today+timedelta(days=days)).isoformat(),now))
        c.execute("INSERT INTO settings(setting_key,setting_value,updated_at) VALUES('demo_data_loaded','true',?) ON CONFLICT(setting_key) DO UPDATE SET setting_value='true',updated_at=excluded.updated_at",(now,))
        c.execute("INSERT INTO settings(setting_key,setting_value,updated_at) VALUES('demo_seeded_once','true',?) ON CONFLICT(setting_key) DO UPDATE SET setting_value='true',updated_at=excluded.updated_at",(now,))


def clear_demo_data(repo: Repository):
    """Remove only tagged demo transactions and demo-created budget/goal records."""
    with session(repo.db_path) as c:
        c.execute("DELETE FROM transactions WHERE tags='DEMO'")
        c.execute("DELETE FROM budgets WHERE is_demo=1")
        c.execute("DELETE FROM savings_goals WHERE is_demo=1")
        c.execute("DELETE FROM settings WHERE setting_key='demo_data_loaded'")
