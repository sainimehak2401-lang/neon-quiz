from io import BytesIO
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from services.analytics_service import transaction_frame, summarize

def export_csv(df):
    return df.to_csv(index=False).encode("utf-8-sig")

def export_excel(df, summary=None):
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        export_df = df.copy()
        if "transaction_date" in export_df:
            export_df["transaction_date"] = pd.to_datetime(export_df["transaction_date"], errors="coerce").dt.strftime("%Y-%m-%d")
        export_df.to_excel(writer, index=False, sheet_name="Transactions")
        if summary is not None:
            pd.DataFrame([summary]).to_excel(writer, index=False, sheet_name="Summary")
        for ws in writer.book.worksheets:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for col in ws.columns:
                width = min(34, max(12, max(len(str(cell.value or "")) for cell in col) + 2))
                ws.column_dimensions[col[0].column_letter].width = width
    return output.getvalue()

def export_pdf(df, title, period, summary):
    output = BytesIO()
    doc = SimpleDocTemplate(output, pagesize=landscape(A4), rightMargin=28, leftMargin=28, topMargin=28, bottomMargin=28)
    styles = getSampleStyleSheet()
    story = [Paragraph("SpendWise — " + title, styles["Title"]), Paragraph("Reporting period: " + period, styles["Normal"]), Spacer(1, 12)]
    story.append(Paragraph(
        f"Income: ₹{summary['income']:,.2f} &nbsp;&nbsp; Expenses: ₹{summary['expenses']:,.2f} &nbsp;&nbsp; Net: ₹{summary['net']:,.2f}",
        styles["Heading2"]))
    story.append(Spacer(1, 10))
    columns = ["Date", "Type", "Category", "Description", "Merchant", "Payment", "Amount (INR)"]
    data = [columns]
    for _, r in df.iterrows():
        date_value = r.get("transaction_date", "")
        if hasattr(date_value, "strftime"): date_value = date_value.strftime("%Y-%m-%d")
        data.append([str(date_value), str(r.get("transaction_type","")), str(r.get("category_name","")),
                     str(r.get("description",""))[:45], str(r.get("merchant",""))[:25],
                     str(r.get("payment_method","")), f"₹{float(r.get('amount',r.get('amount_paise',0)/100)):,.2f}"])
    if len(data) == 1: data.append(["No transactions for this period","","","","","",""])
    table = Table(data, repeatRows=1, colWidths=[68,55,95,160,100,75,80])
    table.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#172238")),
        ("TEXTCOLOR",(0,0),(-1,0),colors.white), ("GRID",(0,0),(-1,-1),0.35,colors.HexColor("#CBD5E1")),
        ("FONTSIZE",(0,0),(-1,-1),8), ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F1F5F9")]),
    ]))
    story.append(table)
    doc.build(story)
    return output.getvalue()
