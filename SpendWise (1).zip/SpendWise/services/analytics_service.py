from datetime import date, timedelta
import pandas as pd
import numpy as np
from database.repository import Repository

def transaction_frame(repo, start=None, end=None, typ=None, category_id=None, payment_method=None, search=None):
    rows = repo.transactions(start, end, typ, category_id, payment_method, search)
    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["id","transaction_type","amount_paise","category_id","transaction_date",
                                     "payment_method","description","merchant","notes","tags","category_name"])
    df["transaction_date"] = pd.to_datetime(df["transaction_date"], errors="coerce")
    df["amount"] = df["amount_paise"].astype("int64") / 100
    return df

def summarize(df):
    if df.empty:
        income = expense = count = 0
    else:
        income = int(df.loc[df.transaction_type == "Income", "amount_paise"].sum())
        expense = int(df.loc[df.transaction_type == "Expense", "amount_paise"].sum())
        count = len(df)
    return {"income_paise": income, "expense_paise": expense, "net_paise": income-expense,
            "income": income/100, "expenses": expense/100, "net": (income-expense)/100,
            "savings_rate": ((income-expense)/income*100) if income else None, "transaction_count": count}

def budget_status(repo, month, year):
    budgets = repo.budgets(month, year)
    rows = repo.transactions(start=f"{year:04d}-{month:02d}-01",
                             end=f"{year:04d}-{month:02d}-{__import__('calendar').monthrange(year,month)[1]:02d}",
                             typ="Expense")
    result = []
    for b in budgets:
        spent = sum(r["amount_paise"] for r in rows if (b["category_id"] is None or r["category_id"] == b["category_id"]))
        amount = b["amount_paise"]
        result.append({**b, "spent_paise": spent, "remaining_paise": amount-spent,
                       "utilization": spent/amount*100 if amount else None,
                       "overspent_paise": max(0, spent-amount)})
    return result

def monthly_series(df):
    if df.empty:
        return pd.DataFrame(columns=["month","Income","Expenses","Savings"])
    data = df.copy()
    data["month"] = data["transaction_date"].dt.to_period("M").dt.to_timestamp()
    pivot = data.pivot_table(index="month", columns="transaction_type", values="amount", aggfunc="sum", fill_value=0)
    for col in ["Income","Expense"]:
        if col not in pivot: pivot[col] = 0
    pivot = pivot.rename(columns={"Expense":"Expenses"})
    pivot["Savings"] = pivot["Income"] - pivot["Expenses"]
    return pivot.reset_index().rename(columns={"Income":"Income"})

def insights(repo, today=None):
    today = today or date.today()
    start = today.replace(day=1).isoformat()
    prev_last = today.replace(day=1) - timedelta(days=1)
    prev_start = prev_last.replace(day=1).isoformat()
    current = transaction_frame(repo, start=start, end=today.isoformat())
    previous = transaction_frame(repo, start=prev_start, end=prev_last.isoformat())
    out = []
    cur = summarize(current); prev = summarize(previous)
    if cur["transaction_count"] < 3:
        out.append(("info", "Build your history", "Add a few more transactions to unlock more reliable month-to-month insights."))
    if cur["expenses"] > cur["income"] and cur["transaction_count"]:
        out.append(("warning", "Spending exceeds income", f"This month's recorded expenses exceed income by ₹{cur['expenses']-cur['income']:,.2f}."))
    if not current.empty:
        expenses = current[current.transaction_type == "Expense"]
        if not expenses.empty:
            by_cat = expenses.groupby("category_name")["amount"].sum().sort_values(ascending=False)
            out.append(("info", "Top spending category", f"{by_cat.index[0]} is your highest expense category this month at ₹{by_cat.iloc[0]:,.2f}."))
            days = max(1, (today - today.replace(day=1)).days + 1)
            out.append(("info", "Average daily spending", f"Your average recorded daily spending is ₹{expenses.amount.sum()/days:,.2f}."))
    if prev["transaction_count"] and cur["transaction_count"]:
        if prev["expenses"]:
            change = (cur["expenses"] - prev["expenses"]) / prev["expenses"] * 100
            direction = "increased" if change > 0 else "decreased"
            out.append(("warning" if change > 0 else "success", "Monthly expense change",
                        f"Expenses {direction} by {abs(change):.1f}% compared with the previous month."))
        if cur["income"] and prev["income"] and cur["savings_rate"] is not None and prev["savings_rate"] is not None:
            delta = cur["savings_rate"] - prev["savings_rate"]
            out.append(("success" if delta >= 0 else "warning", "Savings rate comparison",
                        f"Savings rate {'improved' if delta >= 0 else 'declined'} by {abs(delta):.1f} percentage points versus last month."))
    for b in budget_status(repo, today.month, today.year):
        if b["utilization"] is not None and b["utilization"] >= 75:
            out.append(("error" if b["utilization"] >= 100 else "warning", "Budget alert",
                        f"{b['name']}: {b['utilization']:.0f}% used (₹{b['spent_paise']/100:,.2f} of ₹{b['amount_paise']/100:,.2f})."))
    return out
