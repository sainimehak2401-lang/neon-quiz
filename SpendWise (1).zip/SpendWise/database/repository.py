from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from database.connection import session

def to_paise(value):
    try:
        amount = Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Enter a valid amount.")
    if not amount.is_finite() or amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    return int(amount * 100)

def money(paise):
    return Decimal(int(paise or 0)) / Decimal(100)

def now_text():
    return datetime.now().isoformat(timespec="seconds")

class Repository:
    def __init__(self, db_path=None):
        self.db_path = db_path

    def query(self, sql, params=()):
        with session(self.db_path) as c:
            return [dict(r) for r in c.execute(sql, params).fetchall()]

    def one(self, sql, params=()):
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def execute(self, sql, params=()):
        with session(self.db_path) as c:
            cur = c.execute(sql, params)
            return cur.lastrowid

    def categories(self, typ=None, active_only=False):
        clauses, params = [], []
        if typ:
            clauses.append("transaction_type=?"); params.append(typ)
        if active_only:
            clauses.append("is_active=1")
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        return self.query("SELECT * FROM categories" + where + " ORDER BY transaction_type,name", params)

    def create_category(self, name, typ, description=""):
        name = name.strip()
        if not name: raise ValueError("Category name is required.")
        if typ not in ("Income", "Expense"): raise ValueError("Invalid category type.")
        try:
            return self.execute("INSERT INTO categories(name,transaction_type,description,is_active,created_at) VALUES(?,?,?,?,?)",
                                (name, typ, description.strip(), 1, now_text()))
        except Exception as e:
            if "UNIQUE" in str(e): raise ValueError("A category with this name and type already exists.")
            raise

    def update_category(self, category_id, name, description, active):
        row = self.one("SELECT * FROM categories WHERE id=?", (category_id,))
        if not row: raise ValueError("Category not found.")
        try:
            self.execute("UPDATE categories SET name=?,description=?,is_active=? WHERE id=?",
                         (name.strip(), description.strip(), int(active), category_id))
        except Exception as e:
            if "UNIQUE" in str(e): raise ValueError("A category with this name and type already exists.")
            raise

    def add_transaction(self, data):
        typ = data["transaction_type"]
        amount = to_paise(data["amount"])
        date = str(data["transaction_date"])
        from datetime import date as dt
        try: dt.fromisoformat(date)
        except ValueError: raise ValueError("Enter a valid transaction date.")
        category = self.one("SELECT * FROM categories WHERE id=? AND is_active=1", (int(data["category_id"]),))
        if not category or category["transaction_type"] != typ:
            raise ValueError("Choose an active category matching the transaction type.")
        now = now_text()
        return self.execute("""INSERT INTO transactions
            (transaction_type,amount_paise,category_id,transaction_date,payment_method,description,merchant,notes,tags,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (typ, amount, int(data["category_id"]), date, data.get("payment_method","Other"),
             data.get("description","").strip(), data.get("merchant","").strip(),
             data.get("notes","").strip(), data.get("tags","").strip(), now, now))

    def update_transaction(self, transaction_id, data):
        if not self.one("SELECT id FROM transactions WHERE id=?", (transaction_id,)):
            raise ValueError("Transaction not found.")
        typ = data["transaction_type"]
        amount = to_paise(data["amount"])
        from datetime import date as dt
        date = str(data["transaction_date"])
        try: dt.fromisoformat(date)
        except ValueError: raise ValueError("Enter a valid transaction date.")
        category = self.one("SELECT * FROM categories WHERE id=? AND is_active=1", (int(data["category_id"]),))
        if not category or category["transaction_type"] != typ:
            raise ValueError("Choose an active category matching the transaction type.")
        self.execute("""UPDATE transactions SET transaction_type=?,amount_paise=?,category_id=?,transaction_date=?,
            payment_method=?,description=?,merchant=?,notes=?,tags=?,updated_at=? WHERE id=?""",
            (typ, amount, int(data["category_id"]), date, data.get("payment_method","Other"),
             data.get("description","").strip(), data.get("merchant","").strip(),
             data.get("notes","").strip(), data.get("tags","").strip(), now_text(), transaction_id))

    def delete_transaction(self, transaction_id):
        if not self.one("SELECT id FROM transactions WHERE id=?", (transaction_id,)):
            raise ValueError("Transaction not found.")
        self.execute("DELETE FROM transactions WHERE id=?", (transaction_id,))

    def transactions(self, start=None, end=None, typ=None, category_id=None, payment_method=None, search=None, limit=None, offset=0):
        clauses, params = [], []
        for field, value, op in [
            ("transaction_date", start, ">="), ("transaction_date", end, "<="),
            ("transaction_type", typ, "="), ("category_id", category_id, "="),
            ("payment_method", payment_method, "=")]:
            if value not in (None, ""):
                clauses.append(f"t.{field}{op}?"); params.append(value)
        if search:
            clauses.append("(t.description LIKE ? OR t.merchant LIKE ? OR t.notes LIKE ? OR t.tags LIKE ?)")
            params.extend([f"%{search}%"]*4)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        sql = """SELECT t.*,c.name AS category_name FROM transactions t
                 JOIN categories c ON c.id=t.category_id""" + where + " ORDER BY t.transaction_date DESC,t.id DESC"
        if limit is not None:
            sql += " LIMIT ? OFFSET ?"; params.extend([int(limit), int(offset)])
        return self.query(sql, params)

    def transaction(self, transaction_id):
        return self.one("""SELECT t.*,c.name AS category_name FROM transactions t
                           JOIN categories c ON c.id=t.category_id WHERE t.id=?""", (transaction_id,))

    def budgets(self, month=None, year=None):
        clauses, params = [], []
        if month is not None: clauses.append("b.month=?"); params.append(month)
        if year is not None: clauses.append("b.year=?"); params.append(year)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        return self.query("""SELECT b.*,c.name AS category_name FROM budgets b LEFT JOIN categories c ON c.id=b.category_id"""
                          + where + " ORDER BY b.category_id IS NOT NULL,b.name", params)

    def save_budget(self, name, category_id, amount, month, year):
        paise = to_paise(amount)
        if not 1 <= int(month) <= 12: raise ValueError("Month must be between 1 and 12.")
        if not 2000 <= int(year) <= 2200: raise ValueError("Enter a valid year.")
        if category_id is not None:
            cat = self.one("SELECT * FROM categories WHERE id=? AND transaction_type='Expense' AND is_active=1", (category_id,))
            if not cat: raise ValueError("Budget category must be an active expense category.")
        existing = self.one("SELECT id FROM budgets WHERE category_id IS ? AND month=? AND year=?",
                            (category_id, int(month), int(year)))
        if existing:
            self.execute("UPDATE budgets SET name=?,amount_paise=? WHERE id=?", (name.strip(), paise, existing["id"]))
            return existing["id"]
        return self.execute("INSERT INTO budgets(name,category_id,amount_paise,month,year,created_at) VALUES(?,?,?,?,?,?)",
                            (name.strip(), category_id, paise, int(month), int(year), now_text()))

    def delete_budget(self, budget_id):
        self.execute("DELETE FROM budgets WHERE id=?", (budget_id,))

    def setting(self, key, default=None):
        row = self.one("SELECT setting_value FROM settings WHERE setting_key=?", (key,))
        return row["setting_value"] if row else default

    def set_setting(self, key, value):
        self.execute("""INSERT INTO settings(setting_key,setting_value,updated_at) VALUES(?,?,?)
                        ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at""",
                     (key, str(value), now_text()))
