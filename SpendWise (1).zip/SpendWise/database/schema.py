from datetime import datetime
from database.connection import connect

INCOME_CATEGORIES = [
    "Salary", "Freelancing", "Business Income", "Part-Time Job",
    "Scholarship", "Interest", "Gifts", "Refunds", "Other Income"
]
EXPENSE_CATEGORIES = [
    "Food", "Groceries", "Transportation", "Education", "Rent",
    "Electricity", "Internet", "Mobile Recharge", "Healthcare",
    "Shopping", "Entertainment", "Subscriptions", "Travel",
    "Personal Care", "Family Expenses", "Miscellaneous"
]

def initialize_database(db_path=None):
    conn = connect(db_path)
    try:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL COLLATE NOCASE,
            transaction_type TEXT NOT NULL CHECK(transaction_type IN ('Income','Expense')),
            description TEXT DEFAULT '',
            is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
            created_at TEXT NOT NULL,
            UNIQUE(name, transaction_type)
        );
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY,
            transaction_type TEXT NOT NULL CHECK(transaction_type IN ('Income','Expense')),
            amount_paise INTEGER NOT NULL CHECK(amount_paise > 0),
            category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
            transaction_date TEXT NOT NULL,
            payment_method TEXT NOT NULL DEFAULT 'Other',
            description TEXT DEFAULT '',
            merchant TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            tags TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS budgets (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            category_id INTEGER REFERENCES categories(id) ON DELETE RESTRICT,
            amount_paise INTEGER NOT NULL CHECK(amount_paise > 0),
            month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
            year INTEGER NOT NULL CHECK(year BETWEEN 2000 AND 2200),
            created_at TEXT NOT NULL,
            is_demo INTEGER NOT NULL DEFAULT 0 CHECK(is_demo IN (0,1)),
            UNIQUE(category_id, month, year)
        );
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY,
            setting_key TEXT UNIQUE NOT NULL,
            setting_value TEXT,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS savings_goals (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            target_paise INTEGER NOT NULL CHECK(target_paise > 0),
            saved_paise INTEGER NOT NULL DEFAULT 0 CHECK(saved_paise >= 0),
            target_date TEXT,
            created_at TEXT NOT NULL,
            is_demo INTEGER NOT NULL DEFAULT 0 CHECK(is_demo IN (0,1))
        );
        CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(transaction_date);
        CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category_id);
        CREATE INDEX IF NOT EXISTS idx_transactions_type_date ON transactions(transaction_type, transaction_date);
        CREATE INDEX IF NOT EXISTS idx_budgets_period ON budgets(year, month);
        """)
        # Lightweight forward-compatible migrations for databases created by earlier versions.
        for table in ("budgets", "savings_goals"):
            columns = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
            if "is_demo" not in columns:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN is_demo INTEGER NOT NULL DEFAULT 0")
        now = datetime.now().isoformat(timespec="seconds")
        for typ, names in (("Income", INCOME_CATEGORIES), ("Expense", EXPENSE_CATEGORIES)):
            for name in names:
                conn.execute(
                    "INSERT OR IGNORE INTO categories(name, transaction_type, description, is_active, created_at) VALUES(?,?,?,?,?)",
                    (name, typ, "Default category", 1, now),
                )
        defaults = {
            "currency": "INR", "date_format": "%d %b %Y", "theme": "Dark",
            "budget_warning_1": "75", "budget_warning_2": "90",
            "budget_warning_3": "100", "dashboard_period": "Current month",
        }
        for key, value in defaults.items():
            conn.execute("INSERT OR IGNORE INTO settings(setting_key, setting_value, updated_at) VALUES(?,?,?)",
                         (key, value, now))
        conn.commit()
    finally:
        conn.close()
