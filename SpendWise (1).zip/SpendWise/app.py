from datetime import date, timedelta
import calendar
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from config import APP_NAME, APP_VERSION, PAYMENT_METHODS, DB_PATH, BACKUP_DIR
from database.schema import initialize_database
from database.repository import Repository
from services.analytics_service import transaction_frame, summarize, budget_status, monthly_series, insights
from services.report_service import export_csv, export_excel, export_pdf
from services.backup_service import create_backup, restore_backup
from utils.formatters import currency, paise_currency
from utils.logger import get_logger

st.set_page_config(page_title=APP_NAME, page_icon="💠", layout="wide", initial_sidebar_state="expanded")
try:
    initialize_database()
except Exception as exc:
    get_logger().exception("Database initialization failed")
    st.error("SpendWise could not initialize its local database. Check folder permissions and restart the application.")
    st.stop()

repo = Repository()
# The portfolio/demo build starts with illustrative records on a genuinely empty database.
# The records are tagged DEMO and can be removed from the dashboard. Set
# SPENDWISE_LOAD_DEMO_DATA=0 to disable first-run demo seeding.
import os
if os.environ.get("SPENDWISE_LOAD_DEMO_DATA", "1").strip().lower() not in ("0", "false", "no"):
    if not repo.one("SELECT id FROM transactions LIMIT 1") and repo.setting("demo_seeded_once", "false") != "true":
        try:
            from services.demo_data import load_demo_data
            load_demo_data(repo)
        except Exception:
            get_logger().exception("Demo data initialization failed")
try:
    with open("assets/styles.css", encoding="utf-8") as f: st.markdown(f.read(), unsafe_allow_html=True)
except OSError: pass

def money(value): return currency(value, repo.setting("currency", "INR"))
def get_period():
    today = date.today()
    preset = st.sidebar.selectbox("Reporting period", ["Current month","Previous month","Current year","Last 30 days","All time","Custom range"], key="period")
    if preset == "Current month":
        start, end = today.replace(day=1), today
    elif preset == "Previous month":
        last = today.replace(day=1) - timedelta(days=1); start, end = last.replace(day=1), last
    elif preset == "Current year": start, end = date(today.year,1,1), today
    elif preset == "Last 30 days": start, end = today-timedelta(days=29), today
    elif preset == "Custom range":
        c1,c2 = st.sidebar.columns(2)
        start = c1.date_input("From", today.replace(day=1), key="from_date")
        end = c2.date_input("To", today, key="to_date")
        if start > end:
            st.sidebar.error("Start date must be on or before end date.")
            return None, None
    else: start, end = None, None
    return start, end

def frame_filters():
    start, end = get_period()
    if start is None and end is None and st.session_state.get("period") != "All time":
        return pd.DataFrame(), start, end
    typ = st.sidebar.selectbox("Transaction type", ["All","Income","Expense"])
    cats = repo.categories(active_only=False)
    cat_labels = {"All categories": None}
    cat_labels.update({f"{c['name']} ({c['transaction_type']})":c["id"] for c in cats})
    cat_label = st.sidebar.selectbox("Category", list(cat_labels))
    payment = st.sidebar.selectbox("Payment method", ["All"] + PAYMENT_METHODS)
    df = transaction_frame(repo, start.isoformat() if start else None, end.isoformat() if end else None,
                           None if typ=="All" else typ, cat_labels[cat_label],
                           None if payment=="All" else payment)
    return df, start, end

def title(text, subtitle=None):
    st.title(text)
    if subtitle: st.caption(subtitle)

def chart_layout(fig, height=320):
    fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      margin=dict(l=10,r=10,t=45,b=10), height=height, legend_title_text="")
    st.plotly_chart(fig, use_container_width=True)

def transaction_form(default_type="Expense", row=None, key_prefix="add"):
    typ = st.selectbox("Transaction type", ["Income","Expense"], index=0 if (row or {}).get("transaction_type",default_type)=="Income" else 1, key=f"{key_prefix}_type")
    cats = repo.categories(typ, active_only=True)
    if not cats:
        st.warning(f"No active {typ.lower()} categories. Create one in Categories first."); return
    options = {f"{c['name']} (#{c['id']})":c["id"] for c in cats}
    default_cat = (row or {}).get("category_id")
    labels = list(options)
    idx = next((i for i,k in enumerate(labels) if options[k]==default_cat),0)
    with st.form(f"{key_prefix}_form", clear_on_submit=(row is None)):
        a,b = st.columns(2)
        amount = a.number_input("Amount (₹)", min_value=0.01, value=float((row or {}).get("amount_paise",100)/100), step=10.0, format="%.2f")
        category_label = b.selectbox("Category", labels, index=idx)
        c,d = st.columns(2)
        txn_date = c.date_input("Transaction date", value=date.fromisoformat((row or {}).get("transaction_date",date.today().isoformat())))
        payment = d.selectbox("Payment method", PAYMENT_METHODS, index=PAYMENT_METHODS.index((row or {}).get("payment_method","Other")) if (row or {}).get("payment_method","Other") in PAYMENT_METHODS else 5)
        description = st.text_input("Description", value=(row or {}).get("description",""), max_chars=180)
        merchant = st.text_input("Merchant / source", value=(row or {}).get("merchant",""), max_chars=120)
        notes = st.text_area("Notes", value=(row or {}).get("notes",""), max_chars=1000)
        tags = st.text_input("Tags (comma-separated)", value=(row or {}).get("tags",""), max_chars=200)
        submitted = st.form_submit_button("Save transaction", use_container_width=True)
    if submitted:
        data = {"transaction_type":typ,"amount":amount,"category_id":options[category_label],
                "transaction_date":txn_date.isoformat(),"payment_method":payment,"description":description,
                "merchant":merchant,"notes":notes,"tags":tags}
        try:
            if row: repo.update_transaction(row["id"],data); st.success(f"Transaction #{row['id']} updated.")
            else: repo.add_transaction(data); st.success("Transaction saved successfully.")
            st.rerun()
        except ValueError as e: st.error(str(e))
        except Exception:
            get_logger().exception("Transaction save failed")
            st.error("The transaction could not be saved. Check the inputs and try again.")

with st.sidebar:
    st.markdown("## 💠 SpendWise")
    st.caption("Smart Expense Tracker")
    nav_options = ["Dashboard","Add Transaction","All Transactions","Income Management",
        "Expense Management","Categories","Budget Management","Financial Analytics","Reports and Export","Settings","About SpendWise"]
    if st.session_state.get("nav_override") in nav_options:
        st.session_state["nav_choice"] = st.session_state.pop("nav_override")
    nav_icons = {"Dashboard":"◈  Dashboard", "Add Transaction":"＋  Add Transaction", "All Transactions":"▤  All Transactions",
        "Income Management":"↗  Income Management", "Expense Management":"↘  Expense Management", "Categories":"▦  Categories",
        "Budget Management":"◷  Budget Management", "Financial Analytics":"⌁  Financial Analytics", "Reports and Export":"▧  Reports and Export",
        "Settings":"⚙  Settings", "About SpendWise":"ⓘ  About SpendWise"}
    nav = st.radio("NAVIGATION", nav_options, key="nav_choice", format_func=lambda item: nav_icons.get(item, item))
    st.divider()
    st.caption(f"Version {APP_VERSION}")
    st.caption("Local-first · SQLite storage")

if nav == "Dashboard":
    today = date.today()
    # Compact toolbar like a modern finance SaaS dashboard.
    header_left, header_right = st.columns([3, 1.15])
    with header_left:
        st.markdown(f"<div class='sw-eyebrow'>PERSONAL FINANCE · {today.strftime('%B %Y').upper()}</div><h1 class='sw-greeting'>Good morning, Alex <span>👋</span></h1><div class='sw-subtitle'>Here's your money overview at a glance.</div>", unsafe_allow_html=True)
    with header_right:
        range_choice = st.selectbox("", ["6M", "1M", "3M", "1Y", "All"], index=0, label_visibility="collapsed", key="dash_range")
    if range_choice == "1M": range_start = today.replace(day=1)
    elif range_choice == "3M":
        mi=today.year*12+today.month-1-2; yy,mm=divmod(mi,12); range_start=date(yy,mm+1,1)
    elif range_choice == "6M":
        mi=today.year*12+today.month-1-5; yy,mm=divmod(mi,12); range_start=date(yy,mm+1,1)
    elif range_choice == "1Y": range_start=date(today.year-1,today.month,1)
    else: range_start=None
    df = transaction_frame(repo, range_start.isoformat() if range_start else None, today.isoformat())
    demo_loaded = repo.setting("demo_data_loaded", "false") == "true"
    if df.empty:
        st.markdown("<div class='sw-empty'><div class='sw-empty-icon'>✦</div><h2>Your financial overview starts here</h2><p>Add your first transaction, or load clearly labeled sample records to explore the dashboard and charts.</p></div>", unsafe_allow_html=True)
        ec1, ec2 = st.columns(2)
        with ec1:
            if st.button("＋ Add first transaction", type="primary", use_container_width=True):
                st.session_state["nav_override"] = "Add Transaction"; st.rerun()
        with ec2:
            if st.button("✨ Load sample data", use_container_width=True, help="Adds illustrative demo transactions, budgets and savings goals to this empty database."):
                try:
                    from services.demo_data import load_demo_data
                    load_demo_data(repo)
                    st.success("Sample data loaded. Every sample transaction is tagged DEMO.")
                    st.rerun()
                except Exception as e: st.error(str(e))
        st.markdown("<div class='sw-feature-row'><div><b>↗ Cash flow</b><span>Track income and spending trends.</span></div><div><b>◉ Budget health</b><span>Understand monthly budget usage.</span></div><div><b>⌁ Savings goals</b><span>Follow progress toward your goals.</span></div></div>", unsafe_allow_html=True)
    else:
        if demo_loaded:
            st.markdown("<div class='sw-demo-banner'>DEMO WORKSPACE · Sample records are illustrative, not real financial records.</div>", unsafe_allow_html=True)
        s=summarize(df)
        month_start=today.replace(day=1).isoformat()
        month_df=transaction_frame(repo,start=month_start,end=today.isoformat())
        ms=summarize(month_df)
        budgets=budget_status(repo,today.month,today.year)
        overall=next((b for b in budgets if b["category_id"] is None),None)
        income_delta=None; expense_delta=None
        prev_last=today.replace(day=1)-timedelta(days=1); prev_start=prev_last.replace(day=1)
        prev_df=transaction_frame(repo,start=prev_start.isoformat(),end=prev_last.isoformat())
        prev=summarize(prev_df)
        if prev["income"]: income_delta=f"{(ms['income']-prev['income'])/prev['income']*100:+.1f}% vs last month"
        if prev["expenses"]: expense_delta=f"{(ms['expenses']-prev['expenses'])/prev['expenses']*100:+.1f}% vs last month"
        # KPI row follows the reference: net worth, monthly income, total spent, savings rate.
        k1,k2,k3,k4=st.columns(4, gap="small")
        k1.markdown(f"<div class='sw-kpi sw-kpi-primary'><div class='sw-kpi-label'>NET WORTH</div><div class='sw-kpi-value'>{money(s['net'])}</div><div class='sw-kpi-foot'>All-time recorded net balance</div></div>",unsafe_allow_html=True)
        k2.markdown(f"<div class='sw-kpi'><div class='sw-kpi-label'>MONTHLY INCOME</div><div class='sw-kpi-value'>{money(ms['income'])}</div><div class='sw-kpi-foot'>{income_delta or 'Current month to date'}</div></div>",unsafe_allow_html=True)
        k3.markdown(f"<div class='sw-kpi'><div class='sw-kpi-label'>TOTAL SPENT</div><div class='sw-kpi-value'>{money(ms['expenses'])}</div><div class='sw-kpi-foot'>{expense_delta or 'Current month to date'}</div></div>",unsafe_allow_html=True)
        rate=ms['savings_rate']
        k4.markdown(f"<div class='sw-kpi'><div class='sw-kpi-label'>SAVINGS RATE</div><div class='sw-kpi-value'>{f'{rate:.0f}%' if rate is not None else 'N/A'}</div><div class='sw-kpi-foot'>{'Positive savings' if ms['net']>=0 else 'Expenses exceed income'}</div></div>",unsafe_allow_html=True)
        st.write("")
        left,right=st.columns([1.72,1],gap="small")
        with left:
            st.markdown("<div class='sw-panel-title'><div><h3>Cash Flow Overview</h3><span>Income vs expenses · selected period</span></div><span class='sw-legend'><i class='green-dot'></i> Income&nbsp;&nbsp; <i class='red-dot'></i> Expenses</span></div>",unsafe_allow_html=True)
            series=monthly_series(df)
            if not series.empty:
                fig=go.Figure()
                fig.add_trace(go.Scatter(x=series["month"],y=series["Income"],name="Income",mode="lines+markers",line=dict(color="#14D6A0",width=2.5),marker=dict(size=4),fill="tozeroy",fillcolor="rgba(20,214,160,.08)"))
                fig.add_trace(go.Scatter(x=series["month"],y=series["Expenses"],name="Expenses",mode="lines+markers",line=dict(color="#F16C8B",width=2),marker=dict(size=4),fill="tozeroy",fillcolor="rgba(241,108,139,.06)"))
                fig.update_layout(template="plotly_dark",paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",height=285,margin=dict(l=8,r=8,t=10,b=8),showlegend=False,hovermode="x unified",yaxis=dict(title="Amount (₹)",gridcolor="#22283A",zeroline=False),xaxis=dict(title="",gridcolor="rgba(0,0,0,0)",tickformat="%b"))
                st.plotly_chart(fig,use_container_width=True,config={"displayModeBar":False})
            st.markdown("</div>",unsafe_allow_html=True)
        with right:
            st.markdown("<div class='sw-panel-title'><div><h3>Spending</h3><span>By category · current month</span></div></div>",unsafe_allow_html=True)
            exp=month_df[month_df.transaction_type=="Expense"]
            if exp.empty:
                st.info("No expenses recorded this month.")
            else:
                cat=exp.groupby("category_name",as_index=False).amount.sum().sort_values("amount",ascending=False)
                fig=go.Figure(go.Pie(labels=cat.category_name,values=cat.amount,hole=.68,sort=False,
                    marker=dict(colors=["#3B82F6","#8B5CF6","#14D6A0","#F6C453","#F16C8B","#38BDF8","#A78BFA","#64748B"],line=dict(color="#121525",width=2)),
                    textinfo="none",hovertemplate="%{label}<br>₹%{value:,.0f} · %{percent}<extra></extra>"))
                fig.update_layout(template="plotly_dark",paper_bgcolor="rgba(0,0,0,0)",height=210,margin=dict(l=0,r=0,t=0,b=0),showlegend=False,annotations=[dict(text=f"{money(ms['expenses'])}<br><span style='font-size:10px'>TOTAL SPENT</span>",x=.5,y=.5,showarrow=False,font=dict(size=18,color="#F8FAFC"))])
                st.plotly_chart(fig,use_container_width=True,config={"displayModeBar":False})
                for _,r in cat.head(4).iterrows():
                    pct=(r.amount/exp.amount.sum()*100) if exp.amount.sum() else 0
                    st.markdown(f"<div class='sw-category-row'><span><i class='category-dot'></i>{r.category_name}</span><b>{pct:.0f}% · {money(r.amount)}</b></div>",unsafe_allow_html=True)
        st.write("")
        bottom_left,bottom_right=st.columns([1,1],gap="small")
        with bottom_left:
            st.markdown("<div class='sw-section-head'><h3>Recent Transactions</h3><span>Latest activity</span></div>",unsafe_allow_html=True)
            recent=repo.transactions(limit=6)
            if recent:
                for r in recent:
                    sign="+" if r["transaction_type"]=="Income" else "−"
                    tone="positive" if r["transaction_type"]=="Income" else "negative"
                    icon="↗" if r["transaction_type"]=="Income" else "↘"
                    desc=r["description"] or r["category_name"]
                    merchant=r["merchant"] or r["category_name"]
                    st.markdown(f"<div class='sw-tx-row'><div class='sw-tx-icon'>{icon}</div><div class='sw-tx-main'><b>{desc}</b><span>{merchant} · {r['transaction_date']}</span></div><span class='sw-tag'>{r['category_name']}</span><b class='sw-amount {tone}'>{sign}{money(r['amount_paise']/100)}</b></div>",unsafe_allow_html=True)
            else: st.caption("No recent transactions.")
        with bottom_right:
            st.markdown("<div class='sw-section-head'><h3>Savings Goals</h3><span>Progress tracker</span></div>",unsafe_allow_html=True)
            goals=repo.query("SELECT * FROM savings_goals ORDER BY id LIMIT 5")
            if not goals:
                st.markdown("<div class='sw-empty-small'>No savings goals yet. Load sample data or add a goal below.</div>",unsafe_allow_html=True)
            for g in goals:
                pct=min(100,g["saved_paise"]/g["target_paise"]*100) if g["target_paise"] else 0
                st.markdown(f"<div class='sw-goal-row'><div class='sw-goal-top'><b>{g['name']}</b><span>{pct:.0f}%</span></div><div class='sw-progress'><span style='width:{pct:.2f}%'></span></div><div class='sw-goal-foot'><span>{money(g['saved_paise']/100)} saved</span><span>{money(g['target_paise']/100)} target</span></div></div>",unsafe_allow_html=True)
            with st.expander("＋ Add savings goal"):
                with st.form("goal_form"):
                    goal_name=st.text_input("Goal name")
                    goal_target=st.number_input("Target amount (₹)",min_value=1.0,value=25000.0,step=1000.0)
                    goal_saved=st.number_input("Already saved (₹)",min_value=0.0,value=0.0,step=500.0)
                    goal_date=st.date_input("Target date",value=today+timedelta(days=180))
                    goal_submit=st.form_submit_button("Save goal")
                if goal_submit:
                    if not goal_name.strip(): st.error("Enter a goal name.")
                    elif goal_saved>goal_target: st.error("Saved amount cannot exceed target amount.")
                    else:
                        from database.repository import now_text
                        repo.execute("INSERT INTO savings_goals(name,target_paise,saved_paise,target_date,created_at) VALUES(?,?,?,?,?)",(goal_name.strip(),int(round(goal_target*100)),int(round(goal_saved*100)),goal_date.isoformat(),now_text()))
                        st.success("Savings goal added."); st.rerun()
        if demo_loaded:
            with st.expander("Demo data controls"):
                st.write("Sample records are marked with the DEMO tag. This action removes only the demo-tagged transactions and the demo savings goals/budgets.")
                if st.button("Remove demo data",type="secondary"):
                    try:
                        from services.demo_data import clear_demo_data
                        clear_demo_data(repo); st.success("Demo data removed."); st.rerun()
                    except Exception as e: st.error(str(e))
        with st.expander("Smart financial insights"):
            for level,heading,msg in insights(repo):
                if level=="error": st.error(f"**{heading}** — {msg}")
                elif level=="warning": st.warning(f"**{heading}** — {msg}")
                elif level=="success": st.success(f"**{heading}** — {msg}")
                else: st.info(f"**{heading}** — {msg}")

elif nav == "Add Transaction":
    title("Add transaction","Record income or expenses in your local database.")
    transaction_form()

elif nav in ("All Transactions","Income Management","Expense Management"):
    typ = "Income" if nav=="Income Management" else "Expense" if nav=="Expense Management" else None
    title(nav, "Search, filter, review, edit and delete stored transactions.")
    with st.expander("Filters",expanded=True):
        c1,c2,c3,c4 = st.columns(4)
        start = c1.date_input("From",value=date.today().replace(day=1),key="tx_from")
        end = c2.date_input("To",value=date.today(),key="tx_to")
        types = ["All","Income","Expense"]
        selected_type = typ or c3.selectbox("Type",types)
        cats = repo.categories(typ=selected_type if selected_type!="All" else None)
        cat_options = {"All categories":None,**{f"{c['name']} (#{c['id']})":c["id"] for c in cats}}
        cat_label = c4.selectbox("Category",list(cat_options))
        search = st.text_input("Search description, merchant, notes or tags")
        payment = st.selectbox("Payment method",["All"]+PAYMENT_METHODS)
    if start > end: st.error("Start date must not be after end date."); rows=[]
    else:
        rows=repo.transactions(start.isoformat(),end.isoformat(),typ if typ else (None if selected_type=="All" else selected_type),
                               cat_options[cat_label],None if payment=="All" else payment,search or None)
    df = pd.DataFrame(rows)
    if df.empty: st.info("No transactions match the selected filters.")
    else:
        df["Amount"] = df.apply(lambda r: ("+" if r.transaction_type=="Income" else "−")+money(r.amount_paise/100),axis=1)
        st.dataframe(df[["id","transaction_date","transaction_type","category_name","description","merchant","payment_method","Amount"]].rename(columns={"id":"ID","transaction_date":"Date","transaction_type":"Type","category_name":"Category","description":"Description","merchant":"Merchant","payment_method":"Payment method"}),hide_index=True,use_container_width=True)
        csvdf = df.copy()
        csvdf["amount"] = csvdf["amount_paise"]/100
        st.download_button("Export filtered CSV",export_csv(csvdf),"spendwise_transactions.csv","text/csv")
        st.download_button("Export filtered Excel",export_excel(csvdf),"spendwise_transactions.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        st.divider()
        c1,c2 = st.columns(2)
        with c1:
            edit_id = st.selectbox("Select transaction to edit",df["id"].tolist(),format_func=lambda x:f"#{x} · {df.loc[df.id==x,'transaction_date'].iloc[0]} · {money(df.loc[df.id==x,'amount_paise'].iloc[0]/100)}")
            if st.checkbox("Edit selected transaction",key="edit_toggle"):
                row=repo.transaction(int(edit_id)); row["amount"]=row["amount_paise"]/100
                transaction_form(row["transaction_type"],row,key_prefix=f"edit_{edit_id}")
        with c2:
            delete_id = st.selectbox("Select transaction to delete",df["id"].tolist(),format_func=lambda x:f"#{x} · {df.loc[df.id==x,'transaction_date'].iloc[0]}",key="delete_id")
            if st.checkbox("I understand this permanently deletes the selected transaction",key="confirm_delete"):
                if st.button("Delete transaction",type="primary"):
                    try: repo.delete_transaction(int(delete_id)); st.success("Transaction deleted."); st.rerun()
                    except Exception: get_logger().exception("Transaction delete failed"); st.error("Could not delete transaction.")

elif nav == "Categories":
    title("Category management","Create and maintain income and expense categories. Categories used by transactions are deactivated, not deleted.")
    with st.form("new_category"):
        a,b=st.columns(2); name=a.text_input("Category name"); typ=b.selectbox("Type",["Income","Expense"])
        desc=st.text_input("Description"); submitted=st.form_submit_button("Create category")
    if submitted:
        try: repo.create_category(name,typ,desc); st.success("Category created."); st.rerun()
        except ValueError as e: st.error(str(e))
        except Exception: get_logger().exception("Category creation failed"); st.error("Category could not be created.")
    cats=repo.categories()
    for cat in cats:
        with st.expander(f"{cat['name']} · {cat['transaction_type']} · {'Active' if cat['is_active'] else 'Inactive'}"):
            with st.form(f"cat_{cat['id']}"):
                n=st.text_input("Name",cat["name"]); d=st.text_input("Description",cat["description"] or "")
                active=st.checkbox("Active",bool(cat["is_active"]))
                save=st.form_submit_button("Save category")
            if save:
                try: repo.update_category(cat["id"],n,d,active); st.success("Category updated."); st.rerun()
                except ValueError as e: st.error(str(e))
                except Exception: get_logger().exception("Category update failed"); st.error("Could not update category.")
            related=repo.transactions(category_id=cat["id"])
            st.caption(f"{len(related)} transaction(s) associated with this category. Existing history is preserved.")

elif nav == "Budget Management":
    title("Budget management","Create monthly overall budgets and independent category budgets.")
    today=date.today()
    with st.form("budget_form"):
        a,b,c=st.columns(3)
        name=a.text_input("Budget name", "Monthly overall budget")
        scope=b.selectbox("Budget scope",["Overall budget","Category budget"])
        month=c.selectbox("Month",list(range(1,13)),index=today.month-1,format_func=lambda m:calendar.month_name[m])
        year=st.number_input("Year",min_value=2000,max_value=2200,value=today.year)
        cats=repo.categories("Expense",True)
        catmap={c["name"]:c["id"] for c in cats}
        cat_name=st.selectbox("Expense category",list(catmap)) if scope=="Category budget" and catmap else None
        amount=st.number_input("Budget amount (₹)",min_value=0.01,value=5000.0,step=250.0)
        save=st.form_submit_button("Save budget")
    if save:
        try: repo.save_budget(name,catmap[cat_name] if scope=="Category budget" and cat_name else None,amount,month,year); st.success("Budget saved."); st.rerun()
        except Exception as e: st.error(str(e))
    selected_month=st.selectbox("View month",list(range(1,13)),index=today.month-1,format_func=lambda m:calendar.month_name[m],key="budget_view_month")
    selected_year=st.number_input("View year",min_value=2000,max_value=2200,value=today.year,key="budget_view_year")
    budgets=budget_status(repo,selected_month,int(selected_year))
    if not budgets: st.info("No budgets for this month. Create an overall budget or category budget above.")
    for b in budgets:
        with st.container(border=True):
            st.markdown(f"**{b['name']}** · {b['category_name'] or 'Overall'}")
            st.write(f"Spent {money(b['spent_paise']/100)} of {money(b['amount_paise']/100)} · Remaining {money(b['remaining_paise']/100)}")
            pct=b["utilization"] or 0; st.progress(min(1,max(0,pct/100)))
            if pct>=100: st.error(f"Over budget by {money(b['overspent_paise']/100)}.")
            elif pct>=float(repo.setting("budget_warning_2","90")): st.warning(f"{pct:.1f}% of budget used.")
            elif pct>=float(repo.setting("budget_warning_1","75")): st.info(f"{pct:.1f}% of budget used.")
            if st.button("Delete budget",key=f"delbudget_{b['id']}"):
                st.session_state["pending_budget_delete"]=b["id"]
            if st.session_state.get("pending_budget_delete")==b["id"]:
                st.warning("Confirm deletion?")
                if st.button("Confirm delete",key=f"confirm_budget_{b['id']}"):
                    repo.delete_budget(b["id"]); st.session_state.pop("pending_budget_delete",None); st.rerun()

elif nav == "Financial Analytics":
    title("Financial analytics","Interactive analysis based on recorded transactions.")
    df,start,end=frame_filters()
    if df.empty: st.info("No transactions in this period. Add transactions to unlock analytics.")
    else:
        s=summarize(df); a,b,c,d=st.columns(4)
        a.metric("Income",money(s["income"])); b.metric("Expenses",money(s["expenses"])); c.metric("Net",money(s["net"]))
        d.metric("Average transaction",money(df.amount.mean()))
        exp=df[df.transaction_type=="Expense"]; inc=df[df.transaction_type=="Income"]
        left,right=st.columns(2)
        with left:
            st.subheader("Category spending")
            if exp.empty: st.info("No expenses to analyze.")
            else: chart_layout(px.bar(exp.groupby("category_name",as_index=False).amount.sum().sort_values("amount"),x="amount",y="category_name",orientation="h",labels={"amount":"Expenses (₹)","category_name":"Category"}))
        with right:
            st.subheader("Income sources")
            if inc.empty: st.info("No income to analyze.")
            else: chart_layout(px.pie(inc.groupby("category_name",as_index=False).amount.sum(),names="category_name",values="amount",hole=.55))
        st.subheader("Monthly trend")
        series=monthly_series(df)
        chart_layout(px.line(series,x="month",y=["Income","Expenses","Savings"],markers=True,labels={"month":"Month","value":"Amount (₹)","variable":"Metric"}))
        st.subheader("Payment method usage")
        chart_layout(px.bar(df.groupby("payment_method",as_index=False).size().sort_values("size",ascending=False),x="payment_method",y="size",labels={"payment_method":"Payment method","size":"Transactions"}))
        st.subheader("Rule-based insights")
        for level,heading,msg in insights(repo):
            st.markdown(f"**{heading}** — {msg}")

elif nav == "Reports and Export":
    title("Reports and export","Generate CSV, Excel and PDF reports from stored transactions.")
    today=date.today()
    a,b=st.columns(2)
    start=a.date_input("Report start date",today.replace(day=1),key="report_start")
    end=b.date_input("Report end date",today,key="report_end")
    typ=st.selectbox("Report type",["All transactions","Income report","Expense report"])
    if start>end: st.error("Start date must not be after end date.")
    else:
        df=transaction_frame(repo,start.isoformat(),end.isoformat(),None if typ=="All transactions" else typ.split()[0])
        summary=summarize(df)
        k=st.columns(3); k[0].metric("Income",money(summary["income"])); k[1].metric("Expenses",money(summary["expenses"])); k[2].metric("Net",money(summary["net"]))
        if df.empty: st.info("No transactions found for this report. Exports will contain a valid empty report.")
        export_df=df.copy()
        if not export_df.empty:
            export_df["amount"] = export_df["amount_paise"]/100
            export_df["transaction_date"] = export_df["transaction_date"].dt.strftime("%Y-%m-%d")
        x1,x2,x3=st.columns(3)
        x1.download_button("Download CSV",export_csv(export_df),"spendwise_report.csv","text/csv")
        x2.download_button("Download Excel",export_excel(export_df,summary),"spendwise_report.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        x3.download_button("Download PDF",export_pdf(export_df,typ,f"{start.isoformat()} to {end.isoformat()}",summary),"spendwise_report.pdf","application/pdf")
        st.subheader("Category breakdown")
        if not df.empty:
            exp=df[df.transaction_type=="Expense"]
            if not exp.empty: st.dataframe(exp.groupby("category_name",as_index=False).amount.sum().sort_values("amount",ascending=False).rename(columns={"category_name":"Category","amount":"Expenses (₹)"}),hide_index=True,use_container_width=True)

elif nav == "Settings":
    title("Settings","Preferences apply to this local installation.")
    with st.form("settings_form"):
        currency_code=st.selectbox("Display currency",["INR","USD","EUR","GBP"],index=["INR","USD","EUR","GBP"].index(repo.setting("currency","INR")))
        date_format=st.selectbox("Date format",["%d %b %Y","%Y-%m-%d","%m/%d/%Y"],index=["%d %b %Y","%Y-%m-%d","%m/%d/%Y"].index(repo.setting("date_format","%d %b %Y")))
        warning1=st.slider("Budget heads-up threshold (%)",50,90,int(repo.setting("budget_warning_1","75")))
        warning2=st.slider("Budget warning threshold (%)",60,99,int(repo.setting("budget_warning_2","90")))
        warning3=st.number_input("Exceeded budget threshold (%)",min_value=100,max_value=150,value=int(repo.setting("budget_warning_3","100")))
        save=st.form_submit_button("Save settings")
    if save:
        if warning1>=warning2: st.error("Heads-up threshold must be lower than warning threshold.")
        else:
            for k,v in {"currency":currency_code,"date_format":date_format,"budget_warning_1":warning1,"budget_warning_2":warning2,"budget_warning_3":warning3}.items(): repo.set_setting(k,v)
            st.success("Settings saved."); st.rerun()
    st.divider()
    st.subheader("Database backup")
    st.write("Create a SQLite backup using SQLite's online backup API.")
    if st.button("Create backup now"):
        try:
            path=create_backup()
            st.session_state["backup_path"]=str(path)
            st.success("Backup created.")
        except Exception:
            get_logger().exception("Backup creation failed"); st.error("Backup failed. Check local disk permissions.")
    if st.session_state.get("backup_path"):
        p=__import__("pathlib").Path(st.session_state["backup_path"])
        if p.exists(): st.download_button("Download latest backup",p.read_bytes(),p.name,"application/octet-stream")
    st.subheader("Restore database")
    st.warning("Restoring replaces the active database. A pre-restore backup is created automatically. Export important data before continuing.")
    uploaded=st.file_uploader("Upload a SpendWise SQLite backup",type=["db","sqlite","sqlite3"])
    confirm=st.checkbox("I understand that restore replaces the current database",key="restore_confirm")
    if uploaded and confirm and st.button("Validate and restore backup",type="primary"):
        try: restore_backup(uploaded.getvalue()); st.success("Database restored. Reloading application."); st.rerun()
        except Exception as e: st.error(str(e)); get_logger().exception("Restore failed")
    st.divider()
    st.caption(f"Database initialized: {'Yes' if DB_PATH.exists() else 'No'} · Records stay on this device.")
    st.info("Currency is a display preference only. Changing it does not convert stored amounts. Multi-currency conversion is not implemented.")

elif nav == "About SpendWise":
    title("About SpendWise")
    st.markdown(f"""
    <div class="sw-card">
    <h3>💠 SpendWise — Smart Expense Tracker</h3>
    <p>A local-first personal finance application built with Python, Streamlit, SQLite, Pandas and Plotly.</p>
    <p><b>Version:</b> {APP_VERSION}</p>
    <p><b>Privacy:</b> Transaction data is stored in a local SQLite database and is not sent to an external service by this app.</p>
    <p><b>Important:</b> This application does not provide authentication or database encryption. Protect your device account and maintain backups.</p>
    </div>
    """,unsafe_allow_html=True)
    st.subheader("Implemented modules")
    st.write("Dashboard · Transactions · Income and expenses · Categories · Budgets · Analytics · Rule-based insights · CSV/Excel/PDF exports · Settings · Backup/restore")
    st.subheader("Known limitations")
    st.write("- Single-user local application; no authentication or multi-user synchronization.")
    st.write("- Currency selection changes display symbols only; no foreign-exchange conversion.")
    st.write("- Charts and analytics reflect available transaction history; insights are rule-based, not financial advice.")
    st.write("- Restore requires a valid SQLite backup with the SpendWise schema.")

st.sidebar.divider()
st.sidebar.caption("🔒 Your records remain local to this device.")
