from datetime import date
from services.analytics_service import budget_status

def test_budget_remaining_and_utilization(repo):
    today=date.today(); cat=repo.categories("Expense",True)[0]
    repo.add_transaction({"transaction_type":"Expense","amount":70,"category_id":cat["id"],"transaction_date":today.isoformat()})
    repo.save_budget("Overall",None,100,today.month,today.year)
    repo.save_budget("Category",cat["id"],50,today.month,today.year)
    result=budget_status(repo,today.month,today.year)
    overall=next(x for x in result if x["category_id"] is None)
    category=next(x for x in result if x["category_id"]==cat["id"])
    assert overall["utilization"]==70
    assert overall["remaining_paise"]==3000
    assert category["utilization"]==140
    assert category["overspent_paise"]==2000

def test_zero_budget_rejected(repo):
    from datetime import date
    with __import__("pytest").raises(ValueError):
        repo.save_budget("zero",None,0,date.today().month,date.today().year)
