import pytest
from datetime import date

def data(repo, typ="Expense", amount=12.34):
    cat=repo.categories(typ,True)[0]
    return {"transaction_type":typ,"amount":amount,"category_id":cat["id"],"transaction_date":date.today().isoformat(),
            "payment_method":"UPI","description":"Test","merchant":"Shop","notes":"","tags":"test"}

def test_add_income_and_expense(repo):
    repo.add_transaction(data(repo,"Income",1000))
    repo.add_transaction(data(repo,"Expense",25))
    rows=repo.transactions()
    assert len(rows)==2
    assert {r["transaction_type"] for r in rows}=={"Income","Expense"}

def test_update_and_delete(repo):
    tid=repo.add_transaction(data(repo))
    changed=data(repo,amount=30)
    repo.update_transaction(tid,changed)
    assert repo.transaction(tid)["amount_paise"]==3000
    repo.delete_transaction(tid)
    assert repo.transaction(tid) is None

def test_reject_nonpositive_amount(repo):
    with pytest.raises(ValueError): repo.add_transaction(data(repo,amount=-1))
    with pytest.raises(ValueError): repo.add_transaction(data(repo,amount=0))

def test_reject_invalid_type_or_category(repo):
    d=data(repo); d["transaction_type"]="Other"
    with pytest.raises(ValueError): repo.add_transaction(d)

def test_nonexistent_update(repo):
    with pytest.raises(ValueError): repo.update_transaction(999999,data(repo))

def test_duplicate_category_rejected(repo):
    with pytest.raises(ValueError): repo.create_category("Food","Expense")

def test_deactivate_preserves_history(repo):
    cat=repo.categories("Expense",True)[0]
    tid=repo.add_transaction({"transaction_type":"Expense","amount":10,"category_id":cat["id"],"transaction_date":date.today().isoformat()})
    repo.update_category(cat["id"],cat["name"],cat["description"],False)
    assert repo.transaction(tid) is not None
    with pytest.raises(ValueError): repo.add_transaction({"transaction_type":"Expense","amount":10,"category_id":cat["id"],"transaction_date":date.today().isoformat()})
