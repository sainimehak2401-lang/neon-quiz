from datetime import date
from services.analytics_service import transaction_frame, summarize

def test_empty_analytics(repo):
    df=transaction_frame(repo)
    s=summarize(df)
    assert s["income"]==0 and s["expenses"]==0 and s["savings_rate"] is None

def test_income_expense_net_and_savings(repo):
    today=date.today().isoformat()
    income=repo.categories("Income",True)[0]
    expense=repo.categories("Expense",True)[0]
    repo.add_transaction({"transaction_type":"Income","amount":1000,"category_id":income["id"],"transaction_date":today})
    repo.add_transaction({"transaction_type":"Expense","amount":250,"category_id":expense["id"],"transaction_date":today})
    s=summarize(transaction_frame(repo))
    assert s["income"]==1000 and s["expenses"]==250 and s["net"]==750
    assert s["savings_rate"]==75
