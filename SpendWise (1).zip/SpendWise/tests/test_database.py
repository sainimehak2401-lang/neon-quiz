from database.connection import connect

def test_database_initializes_and_tables_exist(tmp_path):
    from database.schema import initialize_database
    db=tmp_path/"test.db"; initialize_database(db)
    c=connect(db)
    names={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    c.close()
    assert {"transactions","categories","budgets","settings"}.issubset(names)

def test_foreign_keys_enabled(tmp_path):
    from database.schema import initialize_database
    db=tmp_path/"test.db"; initialize_database(db)
    c=connect(db)
    assert c.execute("PRAGMA foreign_keys").fetchone()[0] == 1
    c.close()
