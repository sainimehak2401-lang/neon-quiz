import pytest
from database.schema import initialize_database
from database.repository import Repository

@pytest.fixture
def repo(tmp_path):
    db = tmp_path / "test_spendwise.db"
    initialize_database(db)
    return Repository(db)
